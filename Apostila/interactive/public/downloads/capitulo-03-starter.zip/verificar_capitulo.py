print("Ambiente pronto para o Capítulo 3.")

